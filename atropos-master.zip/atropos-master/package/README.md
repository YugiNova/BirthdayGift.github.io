# Atropos

Atropos is a lightweight, free and open-source JavaScript library to create stunning touch-friendly 3D parallax hover effects.
Available for JavaScript, React and Vue.js

## Getting Started

- [Atropos Website](https://atroposjs.com/)
- [Documentation](https://atroposjs.com/docs)
